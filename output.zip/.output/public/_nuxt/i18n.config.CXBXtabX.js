const l={locale:"id"},a=()=>({legacy:!1,fallbackLocale:l.locale});export{a as default};

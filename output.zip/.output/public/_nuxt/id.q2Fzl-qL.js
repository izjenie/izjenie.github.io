const t={hello:{t:0,b:{t:2,i:[{t:3}],s:"Halo Dunia"}}};export{t as default};

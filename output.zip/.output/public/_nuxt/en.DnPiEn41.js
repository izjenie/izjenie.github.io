const e={hello:{t:0,b:{t:2,i:[{t:3}],s:"Hello World"}}};export{e as default};
